module.exports = {
    mongoURI: "mongodb+srv://dev:uQ1Ak6eYRdFq0hWq@tickets-tgtki.mongodb.net/mern?retryWrites=true&w=majority",
    secretOrKey: "vb#^'Yi;TZ;Z(8x"
}